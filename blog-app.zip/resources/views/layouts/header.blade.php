<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BlogifyHub</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>

<body>
    <div class="bg-gray-50 min-h-screen flex flex-col">
    <header class="px-32 py-5 bg-gray-200 shadow-2xl mb-10">
        <div class="flex h-auto ">
            <div class="w-1/6 h-full flex ">
                <a class="text-3xl text-gray-600" href="/">BlogifyHub</a>
            </div>
            <div class="w-3/6 "></div>
            <div class="w-2/6 ">
                <nav class="flex items-center justify-between">
                    <a class="text-xl text-gray-600 hover:text-gray-900" href="/">Home</a>
                    <a class="text-xl text-gray-600 hover:text-gray-900" href="/blogs">Blogs</a>
                    <a class="text-xl text-gray-600 hover:text-gray-900" href="/about">About</a>
                    <a class="text-xl text-gray-600 hover:text-gray-900" href="/contact">Contact</a>
                </nav>
            </div>
        </div>
    </header>