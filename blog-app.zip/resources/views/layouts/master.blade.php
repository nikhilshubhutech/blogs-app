@include('layouts.header')
<div class="px-32">
    @yield('content')
</div>
@include('layouts.footer')