@extends('layouts.master')
@section('content')
    <h1 class="text-7xl text-center">About Page</h1>
@endsection