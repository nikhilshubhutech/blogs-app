@extends('layouts.master')
@section('content')
    {{ print_r($blog) }}
@endsection