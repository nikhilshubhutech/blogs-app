@extends('layouts.master')
@section('content')
    <h1 class="text-7xl text-center">Contact Page</h1>
@endsection