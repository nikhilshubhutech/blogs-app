<?php

use App\Http\Controllers\About\AboutController;
use App\Http\Controllers\Blogs\BlogController;
use App\Http\Controllers\Contact\ContactController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('pages.home.index');
});

Route::get('/blogs',[BlogController::class,'index'])->name('blogs.index');
Route::get('/blogs/add',[BlogController::class,'create'])->name('blogs.create');
Route::post('/blogs/add',[BlogController::class,'store'])->name('blogs.store');
Route::get('/blogs/{slug}',[BlogController::class,'show'])->name('blogs.show');


Route::get('/about',[AboutController::class,'index']);
Route::get('/contact',[ContactController::class,'index']);
