<?php $__env->startSection('content'); ?>
    <div class="text-6xl text-center font-medium">Blogs</div>
    <div class="max-w-7xl mx-auto px-6 py-10">
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('blogs.show',$blog->slug)); ?>">
                    <div class="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-xl transition">
                        <img src="https://images.unsplash.com/photo-1504215680853-026ed2a45def?w=600" class="w-full h-48 object-cover" alt="Failed to load image" />
                        <div class="p-5">
                            <span
                                class="px-3 py-1 text-xs font-semibold bg-blue-100 text-blue-600 rounded-full"><?php echo e($blog->category->name); ?></span>
                            <h2 class="text-xl font-semibold mt-3"><?php echo e($blog->title); ?></h2>
                            <p class="text-gray-500 text-sm mt-1">
                                <?php echo e($blog->excerpt); ?>

                            </p>
                            <div class="flex items-center gap-3 mt-4">
                                <img src="https://i.pravatar.cc/40?img=1" class="w-10 h-10 rounded-full" />
                                <div>
                                    <p class="text-sm font-semibold">Carrie Brewer</p>
                                    <p class="text-xs text-gray-400"><?php echo e($blog->created_at); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/shubhutech/Laravel-N/practice/blog-app/resources/views/pages/blogs/index.blade.php ENDPATH**/ ?>