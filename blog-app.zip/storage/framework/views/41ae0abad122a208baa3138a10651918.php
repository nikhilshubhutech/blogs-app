<?php $__env->startSection('content'); ?>
    <h1 class="text-7xl text-center">About Page</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/shubhutech/Laravel-N/practice/blog-app/resources/views/pages/about/index.blade.php ENDPATH**/ ?>