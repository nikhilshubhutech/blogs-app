<?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<div class="px-32">
    <?php echo $__env->yieldContent('content'); ?>
</div>
<?php echo $__env->make('layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/shubhutech/Laravel-N/practice/blog-app/resources/views/layouts/master.blade.php ENDPATH**/ ?>