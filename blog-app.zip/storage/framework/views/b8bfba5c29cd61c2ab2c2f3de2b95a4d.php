<?php $__env->startSection('content'); ?>
    <h1>Welcome to the Home Page</h1>
    <p>This is the content of the home page.</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/shubhutech/Laravel-N/practice/blog-app/resources/views/home.blade.php ENDPATH**/ ?>