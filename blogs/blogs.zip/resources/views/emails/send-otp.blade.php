<h1>Hello {{ $user }}</h1>
<p>Please use this otp {{ $otp }} to verify you email.</p>