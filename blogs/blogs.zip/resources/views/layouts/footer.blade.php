<footer>
    <div class="w-full text-center p-8 bg-gray-200 mt-10 shadow-inner">
        &copy; 2024 BlogifyHub. All rights reserved.
    </div>
</footer>
</div>
</body>

</html>