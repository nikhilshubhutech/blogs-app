@include('layouts.header')
<div class="px-32 flex-grow">
    @yield('content')
</div>
@include('layouts.footer')