@extends('layouts.master')
@section('content')
    <h1 class="text-7xl text-center text-gray-700">Contact Page</h1>
@endsection