@extends('layouts.master')
@section('content')
    <div class="flex flex-col items-center justify-center gap-20 mt-24 mb-24">
        <h1 class="text-9xl">Welcome</h1>
        <p class="text-6xl font-medium">To</p>
        <h2 class="text-9xl ">BlogifyHub</h2>
    </div>
@endsection